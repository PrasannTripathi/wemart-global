export const giftsAndArtsBrandData = ["Zoya Products", "SCG Interprices"];

export const fertilizersBrandData = ["Sairadhya"];

export const vebragesBrandData = ["Brews & Blends"];

export const beautycareBrandData = ["LARA","Indo Herbals","Zoya Products","Svasthahita",
"Nrich Solutions","Wellnova Herbals","Wellnova","Shine Herbals","Relish Micro Products","Jivaasri Ayurvedic Wellness","Art n Weaves",];

export const groceryItemsBrandData = ["Organeek"];

export const cowdungProductsBrandData = ["Surya Greens","Vaagmi", "SANATHANA"," Gau Swecha"];

export const sanitaryNapkinsBrandData = ["Apna Greens"];

export const clothingBrandData = ["Vignatha Tailors and Embroiders","Da Trendzz","Jo Collections","Vignatha Tailors and Embroiders"," Da Trendzz"];

export const ecoFriendlyProductsBrandData = ["Relish Micro Products"]

export const brassitemsBrandData = ["Vintage Vaarhi"]

export const houseHoldItemsBrandData = ["AMC", "AMC"]

export const booksBrandData = ["Books"]

export const machinesBrandData = ["Machines"]

export const jewelleryBrandData = ["Tanmay Designer"]

export const furnitureBrandData = ["Pankaj Designer"]

export const homeFurnishingBrandData = ["Soukhya", "Soukhya Enterprises"]

export const ecofriendlyGiftsBrandData = ["Sri Sai Ram"]

export const brassItemsBrandData = ["Vintage "]

export const stationaryBrandData = ["Vaagmi","Akshar Pencil Specifications"]

export const cleaningLiquidBrandData = ["Swiffty"]



