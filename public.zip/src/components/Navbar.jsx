import React from "react";
import { Link, useLocation } from "react-router-dom";

const Navbar = () => {
  const location = useLocation()
  return (
    <div className="bg-gray-100 w-full h-fit p-4 shadow-lg">
      <div className="flex justify-between items-center h-full px-[5%]">
        <h1 className="text-rose-600 font-bold text-3xl font-serif">APNAMART</h1>
        <div>
          <select
            name=""
            id=""
            className="p-2 border border-blue-500 outline-none rounded-l-lg"
          >
            <option value="">Choose Option</option>
            <option value="">Redmi</option>
            <option value="">Oppo</option>
            <option value="">Airtel</option>
            <option value="">Idea</option>
          </select>
          <input
            placeholder="Search...."
            type="text"
            className="w-[350px] outline-none border-blue-500 border p-2 rounded-r-lg"
          />
        </div>
        <button>Login</button>
      </div>
      <div className="flex gap-8 mt-2 w-[1500px] text-nowrap overflow-auto no-scroll">
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/giftsandarts" ? "text-blue-600 font-bold" : "text-gray-600"} `}
          to="/giftsandarts"
        >
          Gifts & Arts
        </Link>
        <Link
          className={`p-1 border-b-2 border-blue-500 ${location.pathname === "/fooditems" ? "text-blue-600 font-bold" : "text-gray-600"}`}
          to="/fooditems"
        >
          Food Items
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/fertilizers" ? "text-blue-600 font-bold" : "text-gray-600"}`}
          to="/fertilizers"
        >
          Fertilizers
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/beverages" ? "text-blue-600 font-bold" : "text-gray-600"}`}
          to="/beverages"
        >
          Beverages
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/beautycare" ? "text-blue-600 font-bold" : "text-gray-600"}`}
          to="/beautycare"
        >
          Beauty Care
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/groceryitems" ? "text-blue-600 font-bold" : "text-gray-600"}`}
          to="/groceryitems"
        >
          Grocery Items
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/cowdungproducts" ? "text-blue-600 font-bold" : "text-gray-600"} `}
          to="/cowdungproducts"
        >
          Cowdung Products
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/sanitarynapkins" ? "text-blue-600 font-bold" : "text-gray-600"} `}
          to="/sanitarynapkins"
        >
          Sanitary Napkins
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/clothing" ? "text-blue-600 font-bold" : "text-gray-600"} `}
          to="/clothing"
        >
          Clothing
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/ecofriendlyproducts" ? "text-blue-600 font-bold" : "text-gray-600"} `}
          to="/ecofriendlyproducts"
        >
          Ecofriendly Products
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/brassitems" ? "text-blue-600 font-bold" : "text-gray-600"} `}
          to="/brassitems"
        >
          Brass Items
        </Link>
        <Link
          className={`p-1 border-b-2  border-blue-500 ${location.pathname === "/householditems" ? "text-blue-600 font-bold" : "text-gray-600"} `}
          to="/householditems"
        >
          Household Items
        </Link>
      </div>
    </div>
  );
};

export default Navbar;
