import React from "react";
import ItemsComponent from "./ItemsComponent";
import fooditemsImage from "../assets/images/fooditems.jpg";
import beautycareImage from "../assets/images/beautycare.jpg";
import homefurnishingImage from "../assets/images/homefurnishing.jpg";
import jewelleryImage from "../assets/images/jewellery.jpg";
import cowdungproductImage from "../assets/images/cowdungproduct.jpg";
import brossidolsImage from "../assets/images/brossidols.jpg";
import cleaningImage from "../assets/images/cleaning.jpg";

const Dashboard = () => {
  return (
    <div className="m-8 ">
      <div className="flex gap-6   flex-wrap">
        {/* Left Image (Big) */}
        <div className="flex-1 rounded-xl overflow-hidden object-contain">
          <img
            src={fooditemsImage}
            alt="Big Image"
            className="w-full h-[458px] "
          />
        </div>

        {/* Right Images (Smaller, Same Height as Big Image) */}
        <div className="flex flex-col justify-between h-[450px]">
          <img
            src={beautycareImage}
            alt="Small Image 1"
            className="w-full h-1/2 object-cover mb-2 rounded-lg"
          />
          <img
            src={homefurnishingImage}
            alt="Small Image 2"
            className="w-full h-1/2 object-cover rounded-lg"
          />
        </div>
      </div>


      <ItemsComponent type="giftsandarts" name="Gifts and Arts" />

      <div className="flex items-center justify-center gap-6">
        <div className="rounded-xl overflow-hidden   h-[300px]">
          <img
            src={jewelleryImage}
            className=" object-contain"
            alt="Image"
          />
        </div>

        <div className=" rounded-xl overflow-hidden  h-[300px]">
          <img
            src={cowdungproductImage}
            alt=""
            className=" object-contain"    
          />
        </div>
      </div>

      <ItemsComponent type="fooditems" name="Food Items" />


      <div className="flex items-center justify-center gap-6">
        <div className="rounded-xl overflow-hidden   h-[300px]">
          <img
            src={brossidolsImage}
            className=" object-contain"
            alt="Image"
          />
        </div>

        <div className=" rounded-xl overflow-hidden  h-[300px]">
          <img
            src={cleaningImage}
            alt=""
            className=" object-contain"    
          />
        </div>
      </div>

      <ItemsComponent type="fertilizers" name="Fertilizers" />
    </div>
  );
};

export default Dashboard;