import React from "react";
import { data } from "../components/ImageData";
import { data1 } from "../components/ImageData";
import { data2 } from "../components/ImageData";
import { data3 } from "../components/ImageData";    
import { data4 } from "../components/ImageData";
const ItemsComponent = ({ type,name }) => {
  // Select data based on the type prop
  const link = "/"+type;
  const selectedData =
    type === "fooditems" ? data : type === "fertilizers" ? data1 : type === "giftsandarts" ? data3: data2
  

  return (
    <div className="my-5">
      <div className="flex mt-5 items-center justify-between">
        <h1 className="text-3xl font-semi ">{name} <div className="bg-blue-600 w-10 h-1 rounded-sm"></div> </h1>
         
        <a href={link} className="text-blue-600">View All</a> 
      </div>
      <div className="mt-5">
        <div className="grid grid-cols-7 gap-8">
          {selectedData.map((item) => (
            <div
              key={item.id}
              className="border-2 border-black bg-white rounded-md flex flex-col gap-2 p-3"
            >
              <img
                className="h-[100px] w-[100px] text-center object-contain ml-[20%] transition-transform duration-300 hover:scale-110"
                src={item.image}
                alt={item.name}
              />
              <div className="flex flex-col text-left gap-4 mx-4">
                <h1>{item.name}</h1>
                <p>₹{item.price}</p>
              </div>
              <div className="flex items-center justify-center">
                <button className="bg-blue-600 p-2 rounded text-white w-[140px]">
                  {item.buttonText}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ItemsComponent;