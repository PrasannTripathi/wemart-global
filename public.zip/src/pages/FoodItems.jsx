import React, { useState } from "react";
import { data, data4, data5, data6, data7, data8 } from "../components/ImageData";
import { data1 } from "../components/ImageData";
import { data2 } from "../components/ImageData";
import { data3 } from "../components/ImageData";

const FoodItems = ({ type }) => {
  const [rangeValue, setRangeValue] = useState(1);

 
  // Select the correct dataset based on `type`
  const selectedData =
    type === "fooditems" ? data : type === "fertilizers" ? data1 : type === "giftsandarts" ? data3: type === "beautycare"? data4: type === "groceryitems" ? data5: type === "cowdungproducts"? data6: type === "sanitarynapkins"? data7: type === "clothing" ? data8: data2;

  return (
    <div className="bg-gray-200 min-h-screen">
      <div className="mx-6 py-4 flex gap-4">
        {/* Sidebar Filters */}
        <div className="bg-white w-[350px] shadow-lg">
          <div className="flex justify-between p-4">
            <button>Filter</button>
            <button className="text-green-500 font-semibold">Apply</button>
            <button className="text-red-600 font-semibold">Clear All</button>
          </div>

          {/* Price Filter */}
          <div className="mx-4">
            <p>Price</p>
            <input
              value={rangeValue}
              onChange={(e) => setRangeValue(e.target.value)}
              type="range"
              min={0}
              max={2996}
              className="w-full"
            />
            <div className="flex justify-between">
              <h1>₹1</h1>
              <p className="text-center">₹{rangeValue}</p>
            </div>
          </div>

          {/* Sort By */}
          <div className="mx-4 my-3">
            <p>Sort By</p>
            <div className="flex flex-col gap-2 px-3 py-4">
              <p className="flex gap-2 items-center">
                <input type="checkbox" /> Popularity
              </p>
              <p className="flex gap-2 items-center">
                <input type="checkbox" /> Price - Low to High
              </p>
              <p className="flex gap-2 items-center">
                <input type="checkbox" /> Price - High to Low
              </p>
              <p className="flex gap-2 items-center">
                <input type="checkbox" /> New Arrivals
              </p>
            </div>
          </div>

          {/* Discount */}
          <div className="mx-4 my-3">
            <p>Discount</p>
            <div className="flex flex-col gap-2 px-3 py-2">
              {["50%", "40%", "30%", "20%", "10%"].map((discount) => (
                <p key={discount} className="flex gap-2 items-center">
                  <input type="checkbox" /> {discount} or more
                </p>
              ))}
            </div>
          </div>

          {/* Brand */}
          <div className="mx-4 my-3">
            <p>Brand</p>
            <div className="flex flex-col gap-2 px-3 py-2">
              <p className="flex gap-2 items-center">
                <input type="checkbox" /> Zoya Products
              </p>
              <p className="flex gap-2 items-center">
                <input type="checkbox" /> SCG Enterprises
              </p>
            </div>
          </div>
        </div>

        {/* Product Grid */}
        <div>
          <div className="grid grid-cols-5 gap-4">
            {selectedData.map((item) => (
              <div
                key={item.id}
                className="border-2 border-black bg-white rounded-md flex flex-col gap-2 p-3"
              >
                <img
                  className="h-[200px] w-[200px] object-contain transition-transform duration-300 hover:scale-110"
                  src={item.image}
                  alt={item.name}
                />
                <div className="flex flex-col gap-4 mx-4">
                  <h1>{item.name}</h1>
                  <p>₹{item.price}</p>
                </div>
                <div className="flex items-center justify-center">
                  <button className="bg-blue-600 p-2 rounded text-white w-[140px]">
                    {item.buttonText}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FoodItems;
